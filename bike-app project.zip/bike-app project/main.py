import requests
from sqlalchemy import create_engine, text
import schedule
import time
from datetime import datetime
import traceback

# Database connection details
USER = "admin"
PASSWORD = "noel030800"  # Replace with your actual RDS password
PORT = "3307"  # Local forwarded port via SSH tunnel
DB = "database-1"
URI = "127.0.0.1"  # Use localhost because you're tunneling

# Create the SQLAlchemy connection engine
connection_string = f"mysql+mysqldb://{USER}:{PASSWORD}@{URI}:{PORT}/{DB}"
engine = create_engine(connection_string, echo=True)

# JCDecaux API Details
API_KEY = "d60cb90a6497a2035c91718f581d2eaa6419d7e0"  # Replace with your JCDecaux API key
CONTRACT = "dublin"
API_URL = f"https://api.jcdecaux.com/vls/v1/stations?contract={CONTRACT}&apiKey={API_KEY}"

# Logging Configuration
LOG_FILE = "output.log"

def log_message(message):
    """Write logs to a file and print to console."""
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(message + "\n")
    print(message)

def convert_timestamp(unix_timestamp):
    """Convert Unix timestamp (milliseconds) to MySQL DATETIME format."""
    return datetime.utcfromtimestamp(unix_timestamp / 1000).strftime('%Y-%m-%d %H:%M:%S')

def update_bike_data():
    """Fetch data from the JCDecaux API and update the database."""
    try:
        response = requests.get(API_URL, timeout=10)
        response.raise_for_status()
        stations = response.json()
        log_message(f"Fetched {len(stations)} stations from JCDecaux API.")
    except requests.exceptions.RequestException as e:
        log_message(f"API Request Error: {e}")
        return

    try:
        with engine.connect() as connection:
            transaction = connection.begin()
            for station in stations:
                static_sql = text("""
                    INSERT INTO stations (
                        station_id, contract_name, name, address, latitude, longitude, total_bike_stands
                    )
                    VALUES (
                        :station_id, :contract_name, :name, :address, :latitude, :longitude, :total_bike_stands
                    )
                    ON DUPLICATE KEY UPDATE 
                        contract_name = VALUES(contract_name),
                        name = VALUES(name),
                        address = VALUES(address),
                        latitude = VALUES(latitude),
                        longitude = VALUES(longitude),
                        total_bike_stands = VALUES(total_bike_stands)
                """)
                connection.execute(static_sql, {
                    "station_id": station["number"],
                    "contract_name": station["contract_name"],
                    "name": station["name"],
                    "address": station["address"],
                    "latitude": station["position"]["lat"],
                    "longitude": station["position"]["lng"],
                    "total_bike_stands": station["bike_stands"]
                })

                dynamic_sql = text("""
                    INSERT INTO station_status (
                        station_id, available_bikes, available_bike_stands, status, last_update
                    )
                    VALUES (
                        :station_id, :available_bikes, :available_bike_stands, :status, :last_update
                    )
                    ON DUPLICATE KEY UPDATE 
                        available_bikes = VALUES(available_bikes),
                        available_bike_stands = VALUES(available_bike_stands),
                        status = VALUES(status),
                        last_update = VALUES(last_update)
                """)
                connection.execute(dynamic_sql, {
                    "station_id": station["number"],
                    "available_bikes": station["available_bikes"],
                    "available_bike_stands": station["available_bike_stands"],
                    "status": station["status"],
                    "last_update": convert_timestamp(station["last_update"])
                })
            transaction.commit()
        log_message("Data inserted/updated successfully in the database.")
    except Exception as e:
        log_message(f"Database Error: {e}")
        log_message(traceback.format_exc())

# Schedule the update
update_bike_data()
schedule.every(1).hours.do(update_bike_data)

log_message("Scheduler started. The bike data will update every hour.")
while True:
    schedule.run_pending()
    time.sleep(60)
